package ar.com.eduit.curso.java.adv.sockets;

public class Clase03 {
    public static void main(String[] args) {
        /*
        
        Protocolo TCP/IP
        
        Server                                              Client
        ---------                                           ---------
        ServerSocket ss=new ServerSocket(int port);         Socket so=new Socket(String ip,int port);
        ss.accept();
        ---------                                           ---------  
        InputStream                 <---------------        OutputStream
        OutputStream                --------------->        InputStream
        ---------                                           ---------   
        ss.close()                                          so.close();
        
        BufferedWriter - BufferedReader:        Streams de buffers.
        DataInputStream - DataOutputStream:     Streams de datos primitivos.
        ObjectInputStream - ObjectOutputStream: Streams de objetos.
        
        */
    }
}
