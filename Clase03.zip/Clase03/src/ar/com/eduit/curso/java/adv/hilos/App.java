package ar.com.eduit.curso.java.adv.hilos;

public class App {
    public static void main(String[] args) {
        
        Saludo saludo=new Saludo();
        Empleado javier=new Empleado("Javier",false,saludo);
        Empleado ana=new Empleado("Ana",false,saludo);
        Empleado jose=new Empleado("Jose",false,saludo);
        Empleado maria=new Empleado("Maria",false,saludo);
        Empleado jefe=new Empleado("Darth Vader",true,saludo);
        
        javier.start();
        ana.start();
        jose.start();
        maria.start();
        try { Thread.sleep(1000); } catch(Exception e) {}
        jefe.start();
        
        
    }
}
