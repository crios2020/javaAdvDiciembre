package ar.com.eduit.curso.java.adv.hilos;
public class Empleado extends Thread{
    private String nombre;
    private boolean esJefe;
    private Saludo saludo;

    public Empleado(String nombre, boolean esJefe, Saludo saludo) {
        this.nombre = nombre;
        this.esJefe = esJefe;
        this.saludo = saludo;
    }

    @Override
    public void run() {
        this.saludo.saludar(nombre, esJefe);
    }
    
    
}
