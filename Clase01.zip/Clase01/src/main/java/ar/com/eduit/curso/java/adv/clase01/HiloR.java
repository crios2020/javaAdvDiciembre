package ar.com.eduit.curso.java.adv.clase01;
public class HiloR implements Runnable {
    //Interface Runnable
    private String nombre;
        
    public HiloR(String nombre) {
        this.nombre = nombre;
    }
    @Override
    public void run(){
        //Este método puede ejecutarse en un nuevo Thread
        for(int a=1;a<=10;a++){
            System.out.println(nombre+" "+a);
            dormir();
        }
    } 

    private void dormir() {
        try { Thread.sleep(1000); } catch(Exception e) {}
    }
    
}
