package ar.com.eduit.curso.java.adv.clase01;
public class HiloT extends Thread {
    //La clase Thread permite ejecutar un método en un nuevo Thread (Hilo)
    private String nombre;
    public HiloT(String nombre) {
        this.nombre = nombre;
    }
    @Override
    public void run(){
        //Este método puede ejecutarse en un nuevo Thread
        for(int a=1;a<=10;a++){
            System.out.println(nombre+" "+a);
            dormir();
        }
    } 

    private void dormir() {
        try { Thread.sleep(1000); } catch(Exception e) {}
    }
}
