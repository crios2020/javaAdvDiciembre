package ar.com.eduit.curso.java.adv.clase01;
public class Clase01 {
    public static void main(String[] args) {
        /*
        Curso: Java Advanced 15 horas.
        Días: Lunes 10:00 a 13:00 horas.
        Profe: Carlos Ríos.     carlos.rios@educacionit.com
        Materiales: alumni.educacionit.com
        Github: https://github.com/crios2020/javaAdvDiciembre
        
        JDK LTS y un IDE
        
        */
        
        /*
        Tarea 1:    Leer file1 en medio 1               10 s
        Tarea 2:    Leer file2 en medio 2               10 s
        Tarea 3:    Abrir Form y mostrar file1 y file2   1 s
        
          Tarea 1    Tarea 2   Tarea 3
        |----------|----------|-|
            10 s        10 s   1 s
        
        Total:  21 s
        
          Tarea 1
        |----------|
            10 s
        
          Tarea 2
        |----------|
            10 s    
                    Tarea 3
                    |-|
                     1 s
        
        Total: 11 s
        
        
          Tarea 1
        |----------|
            10 s
        
            Tarea 2
        |----------|
            10 s  
        
        Tarea 3
        |-|
         1 s
        
        Total: 10 s
 
        */
        
        HiloT hiloT1 = new HiloT("hiloT1");
        HiloT hiloT2 = new HiloT("hiloT2");
        HiloT hiloT3 = new HiloT("hiloT3");
        HiloT hiloT4 = new HiloT("hiloT4");
        
        //método .run();
        //Invocar directamente el método no abre un nuevo hilo de ejecución
        //hiloT1.run();
        //hiloT2.run();
        //hiloT3.run();
        //hiloT4.run();
          
        //método .start()
        //Este método, invoca al método .run() en un nuevo hilo
        //hiloT1.start();
        //hiloT2.start();
        //hiloT3.start();
        //hiloT4.start();
        //thread anonimo
        //new HiloT("hiloT5").start();
        
        HiloR hiloR1=new HiloR("HiloR1");
        HiloR hiloR2=new HiloR("HiloR2");
        HiloR hiloR3=new HiloR("HiloR3");
        HiloR hiloR4=new HiloR("HiloR4");
        HiloR hiloR6=new HiloR("HiloR6");
        
        Thread t1=new Thread(hiloR1);
        Thread t2=new Thread(hiloR2);
        Thread t3=new Thread(hiloR3);
        Thread t4=new Thread(hiloR4);
        //Runnable anonimo
        Thread t5=new Thread(new HiloR("HiloR5"));
        
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        //Thread Anonimo
        new Thread(hiloR6).start();
        //Runnable y Thread anonimo
        new Thread(new HiloT("HiloR7")).start();
        
        
    }
}
