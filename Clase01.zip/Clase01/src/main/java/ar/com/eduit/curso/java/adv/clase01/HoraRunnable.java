package ar.com.eduit.curso.java.adv.clase01;
import java.text.DecimalFormat;
import javax.swing.JTextField;
import java.time.LocalTime;
public class HoraRunnable implements Runnable {
    private JTextField txt;
    private static final DecimalFormat df=new DecimalFormat("00");
    
    public HoraRunnable(JTextField txt) {
        this.txt = txt;
    }

    @Override
    public void run() {
       while(true){
           LocalTime lt=LocalTime.now();
           int hour=lt.getHour();
           int minute=lt.getMinute();
           int second=lt.getSecond();
           txt.setText(df.format(hour)+":"+df.format(minute)+":"+df.format(second));
           try { Thread.sleep(1000); } catch(Exception e) {}
       }
    }  
}
