package ar.com.eduit.curso.java.adv.serializado;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class App {
    public static void main(String[] args) {
        
        File file=new File("datos.dat");
        
        //Serializado de Objetos
        try (ObjectOutputStream out=new ObjectOutputStream(
                new FileOutputStream(file))){
            out.writeObject(new Persona("Juan","Perez",38));
            out.writeObject(new Persona("Debora","Lopez",23));
            out.writeObject(new Persona("Eliana","Correa",29));
            out.writeObject(new Persona("Karina","Perez",38));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        //DesSerializado de Objetos
        try(ObjectInputStream in=new ObjectInputStream(
                new FileInputStream(file))){
            while(true){
                Persona p=(Persona)in.readObject();
                System.out.println(p);
            }
        } catch (EOFException e) { System.out.println("-- Fin del Archivo --");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
