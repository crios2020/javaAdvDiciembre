package ar.com.eduit.curso.java.adv.chat;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapaDirecciones {
    public static Map<String,String> getMapa(){
        Map<String,String>map=new LinkedHashMap();
        map.put("Carlos", "192.168.0.3");
        map.put("Cristian","192.168.0.4");
        return map;
    }
}