package ar.com.eduit.curso.java.adv.sockets;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Comparator;

public class ClienteMinimo2 {
    public static void main(String[] args) {
        String line;
        try (
                //Socket so=new Socket("localhost",5000);
                //BufferedReader in=new BufferedReader(new InputStreamReader(so.getInputStream()));
                BufferedReader in=new BufferedReader(
                        new InputStreamReader(
                                new Socket("localhost",5000).getInputStream()
                        )
                );
            ){
                //while((line=in.readLine())!=null){
                //    System.out.println(line);
                //}
                
                //in.lines().forEach(System.out::println);
                
                // ************************************************************
                
                // repasar expresión Lamda
                // repasar concepto de Stream
                
                // ************************************************************
                
                //for(byte b:in.readAllBytes()) System.out.print((char)b);
                
                //in.lines().forEach(x->System.out.println(x));
                //in.lines().forEach(System.out::println);
                
                // listar los elementos que contienen la letra M
                //in
                //        .lines()
                //        .filter(x->x.toLowerCase().contains("m"))
                //        .forEach(System.out::println);
                
                //listar los elementos ordenados alfabeticamente A-Z
                //in.lines().sorted().forEach(System.out::println);
                in.lines().sorted(Comparator.reverseOrder()).forEach(System.out::println);
                
                
                
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
